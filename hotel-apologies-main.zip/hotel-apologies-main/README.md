# hotel-apologies

1. Raw Tripadvisor Reviews data ais scraped with Tripadvisor Scraper.ipynb
2. Scraped Tripadvisor Reviews data is processed with Filter Tripadvisor data.ipynb
3. After processing through LIWC and TextAnalyzer, the data is processed with Filter response data.ipynb and put into format inputtable to apology_model.R code
4. Run apology_model.R to train the models
